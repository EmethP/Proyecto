<?php 
include_once("../class/Alumno.php");

$sMatric=$_POST["sMatric"];
$sPwd=$_POST["sPwd"];

$oUsu=null;
$oUsu=new Alumno();
$oUsu->setsMatricula($sMatric);
$oUsu->setsPwd($sPwd);

if($oUsu->login()){
	setcookie("sNombre",$oUsu->getsNom()." ".$oUsu->getsApp()." ".$oUsu->getsApm()." ".$sMatric ,0, '/');
	setcookie("sCarrera", $oUsu->getsCarrera(),0, '/');
	header("Location: ../login.php");
}else{
	header("Location: ../index.html");
}
?>