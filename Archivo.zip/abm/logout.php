<?php

if (isset($_COOKIE['sNombre']) && isset($_COOKIE['sCarrera'])) {
    unset($_COOKIE['sNombre']);
    unset($_COOKIE['sCarrera']);
    setcookie('sCarrera', null, -1, '/');
    setcookie('sNombre', null, -1, '/');
}
header("Location: ../index.html");
?>