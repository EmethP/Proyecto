<?php
/*************************************************************/
/* AccesoDatos.php
 * Objetivo: clase que encapsula el acceso a la base de datos
 * Autor: BAOZ
 *************************************************************/
 error_reporting(E_ALL);
 class AccesoDatos{
 private $oConexion=null; 
 public $id=0;
		/*Realiza la conexión a la base de datos*/
     	function conectar(){
		$bRet = false;
			try{
				$this->oConexion = new mysqli("localhost", "root", "", "sii_escolar");
				$this->oConexion->set_charset("utf8");
			}catch(Exception $e){
				throw $e;
			}
			if (mysqli_connect_error())
				throw new Exception(mysqli_connect_error());
			else
				$bRet = true;
			return $bRet;
		}
		
		/*Realiza la desconexión de la base de datos*/
     	function desconectar(){
		$bRet = true;
			if ($this->oConexion != null){
				$bRet = $this->oConexion->close();
			}
			return $bRet;
		}
		
		/*Ejecuta en la base de datos la consulta que recibió por parámetro.
		Regresa
			Nulo si no hubo datos
			Un arreglo bidimensional de n filas y tantas columnas como campos se hayan
			solicitado en la consulta*/
      	function ejecutarConsulta($psConsulta){
		$arrRS = null;
		$rst = null;
		$oDato = null;
		$sValCol = "";
		$i=0;
		$j=0;
			if ($psConsulta == ""){
		       throw new Exception("AccesoDatos->ejecutarConsulta: falta indicar la consulta");
			}
			if ($this->oConexion == null){
				throw new Exception("AccesoDatos->ejecutarConsulta: falta conectar la base");
			}
			try{
				$rst = $this->oConexion->query($psConsulta);
			}catch(Exception $e){
				throw $e;
			}
			if ($this->oConexion->error == ""){
				while($oDato = $rst->fetch_object()){ 
					foreach($oDato as $sValCol){
						$arrRS[$i][$j] = $sValCol;
						$j++;
					}
					$j=0;
					$i++;
				}
				$rst->close();
			}
			else{
				throw new Exception($this->oConexion->error);
			}
			return $arrRS;
		}
		
		/*Ejecuta en la base de datos el comando que recibió por parámetro
		Regresa
			el número de registros afectados por el comando*/

		function getIdGenerado($object){
				$this->id = $object;
				return $this->id;
		}

		function getConexion(){
			return $this->oConexion;
		}

      	function ejecutarComando($psComando){
		$nAfectados = -1;
	       if ($psComando == ""){
		       throw new Exception("AccesoDatos->ejecutarComando: falta indicar el comando");
			}
			if ($this->oConexion == null){
				throw new Exception("AccesoDatos->ejecutarComando: falta conectar la base");
			}
			try{
	       	  $this->oConexion->query($psComando);

			   $nAfectados = $this->oConexion->affected_rows;
			   $this->getIdGenerado($this->oConexion->insert_id);
			}catch(Exception $e){
				throw $e;
			}
			return $nAfectados;
		}

      	function ejecutarComandoCaracterEspecial($psComando){

		$nAfectados = -1;
	       if ($psComando == ""){
		       throw new Exception("AccesoDatos->ejecutarComando: falta indicar el comando");
			}
			if ($this->oConexion == null){
				throw new Exception("AccesoDatos->ejecutarComando: falta conectar la base");
			}
			try{
				$psComando2="";
				$psComando2=mysql_real_escape_string($psComando);
	       	  $this->oConexion->query($psComando2);

			   $nAfectados = $this->oConexion->affected_rows;
			   $this->getIdGenerado($this->oConexion->insert_id);
			}catch(Exception $e){
				throw $e;
			}
			return $nAfectados;
		}
	}
 ?>