<?php
include_once("Usuario.php");
class Alumno extends Usuario{

	private $sMatricula="";
	private $sCarrera="";

	function setsMatricula($sMatricula){
		$this->sMatricula=$sMatricula;
	}
	function getsMatricula(){
		return $this->sMatricula;
	}
	function setsCarrera($sCarrera){
		$this->sCarrera=$sCarrera;
	}
	function getsCarrera(){
		return $this->sCarrera;
	}

	function login(){
	   $sQuery="";
	   $sQuery="SELECT a.sNombres, a.sApp, a.sApm, c.sNomCarrera 
			 FROM tbl_usuario as u inner join tbl_alumno as a on a.sMatricula =u.sMatricula inner join  tbl_carrera as c ON a.nIdCarrera=c.nIdcarrera where u.sPwd ='".$this->getsPwd()."' and u.sMatricula='".$this->getsMatricula()."';";

         $oAD=null;
         $oAD=new AccesoDatos();
         $arrTodos=null;
         $arrLinea=null;
         $oPost=null;
         $j=0;
         if($oAD->conectar()){
             $arrRS=$oAD->ejecutarConsulta($sQuery);
             
             if ($arrRS){
				foreach($arrRS as $arrLinea){
						$this->setsNom($arrLinea[0]);
					    $this->setsApp($arrLinea[1]);
					    $this->setsApm($arrLinea[2]);
					    $this->setsCarrera($arrLinea[3]);
			             			
                }
			}
             $oAD->desconectar();
         }else{
             die("Error al conectar");
         }
         
         return $this;

	}

}
?>