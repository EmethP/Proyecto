<?php
include_once("AccesoDatos.php");
class Usuario{

	private $sUsuario="";
	private $sPwd="";
	private $sNom="";
	private $sApp="";
	private $sApm="";
	private $sCorreo="";

	function setsApp($sApp){
		$this->sApp=$sApp;
	}
	function getsApp(){
		return $this->sApp;
	}
	function setsApm($sApm){
		$this->sApm=$sApm;
	}
	function getsApm(){
		return $this->sApm;
	}
	function setsUsuario($sUsuario){
		$this->sUsuario=$sUsuario;
	}
	function getsUsuario(){
		return $this->sUsuario;
	}
	function setsPwd($sPass){
		$this->sPwd=$sPass;
	}
	function getsPwd(){
		return $this->sPwd;
	}
	function setsNom($sNom){
		$this->sNom=$sNom;
	}

	function getsNom(){
		return $this->sNom;
	}
	function setsCorreo($sCorreo){
		$this->sCorreo=$sCorreo;
	}
	function getsCorreo(){
		return $this->sCorreo;
	}


	function insertar(){
		$res=0;
		if($this->getsUsuario()==""){
			die("ERROR, FALTAN DATOS");
		}
		else{
		
	        $oAD=null;
	        $oAD=new AccesoDatos();
	        if($oAD->conectar()){
	        	
	       $sQuery="insert into usuarios (sUsuario,sPass,sCorreo,sNombre) values('".$this->sUsuario."','".$this->sPass."','".$this->sCorreo."','".$this->sNom."');";
	       
	        $res=$oAD->ejecutarComando($sQuery);
	  
	        $oAD->desconectar();
	        }else{
	            die("Error al conectar");
       		}
        
        }
        return $res;

}
/*
	function login(){
	   $sQuery="select * from usuarios where sUsuario='".$this->sUsuario."' and sPass='".$this->sPass."'";
         $oAD=null;
         $oAD=new AccesoDatos();
         $arrTodos=null;
         $arrLinea=null;
         $oPost=null;
         $j=0;
         if($oAD->conectar()){
             $arrRS=$oAD->ejecutarConsulta($sQuery);
             
             if ($arrRS){
				foreach($arrRS as $arrLinea){
							
								$this->setsUsuario($arrLinea[0]);
							    $this->setsNom($arrLinea[2]);
			             			
                }
			}
             $oAD->desconectar();
         }else{
             die("Error al conectar");
         }
         
         return $this;

	}
*/


}
?>