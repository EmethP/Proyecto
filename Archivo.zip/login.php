<?php 
if(!isset($_COOKIE["sNombre"]) || empty($_COOKIE["sNombre"]) || !isset($_COOKIE["sCarrera"]) || empty($_COOKIE["sCarrera"])){
	header("Location: index.html");

}else{
	$sNombreMtric="";
	$sCarrera="";
	$sNombreMtric=$_COOKIE["sNombre"];
	$sCarrera=$_COOKIE["sCarrera"];
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

<link rel="stylesheet" type="text/css" href="css/style.css">
<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
	<title>Sistema Integral de Información</title>
<style type="text/css">
	.well {
    background: rgb(244,249,244);
}
</style>
</head>
<body>
<header>
	<nav class="navbar navbar-default" role="navigation">
  <!-- El logotipo y el icono que despliega el menú se agrupan
       para mostrarlos mejor en los dispositivos móviles -->
  <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse"
            data-target=".navbar-ex1-collapse">
      <span class="sr-only">Desplegar navegación</span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
    </button>
    <a class="navbar-brand" href="#">ISECF</a>
  </div>
 
  <!-- Agrupar los enlaces de navegación, los formularios y cualquier
       otro elemento que se pueda ocultar al minimizar la barra -->
  <div class="collapse navbar-collapse navbar-ex1-collapse">
    <ul class="nav navbar-nav">
      <li class="dropdown">
      <a href="#" class="dropdown-toggle" data-toggle="dropdown">Servicios <b class="caret"></b> </a>
       <ul class="dropdown-menu">
          <li><a href="#">Cardex</a></li>
          <li><a href="#">Cardex Gráfico</a></li>
          <li><a href="#">Evaluación Docente</a></li>
          <li class="divider"></li>
          <li><a href="#">Acción #4</a></li>
          <li class="divider"></li>
          <li><a href="#">Acción #5</a></li>
        </ul>

      </li>

      <li><a href="#">Biblioteca Digital</a></li>

      <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
         Descargas <b class="caret"></b>
        </a>
        <ul class="dropdown-menu">
          <li><a href="#">Acción #1</a></li>
          <li><a href="#">Acción #2</a></li>
          <li><a href="#">Acción #3</a></li>
          <li class="divider"></li>
          <li><a href="#">Acción #4</a></li>
          <li class="divider"></li>
          <li><a href="#">Acción #5</a></li>
        </ul>
      </li>
    </ul>
 
   
 
    <ul class="nav navbar-nav navbar-right">
     
      <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
         <?php echo $sNombreMtric;?> <b class="caret"></b>
        </a>
        <ul class="dropdown-menu">
          <li><a href="#">Acción #1</a></li>
          <li><a href="#">Acción #2</a></li>
          <li><a href="#">Acción #3</a></li>
          <li class="divider"></li>
          <li><a href="abm/logout.php">Cerrar Sesión</a></li>
        </ul>
      </li>
    </ul>
  </div>
</nav>

</header>




	<div class="container well">
		<div class="row main">
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" >
				<h4 class="text-center">
				
				<div class="glyphicon glyphicon-user"></div> Bienvenid@ 
				</h4>
				<h4 class="text-center">
					<?php echo $sNombreMtric;?>
				</h4>
				<img src="images/user.png" class="img-responsive center-block">
				<h5 class="text-center">CARRERA: <strong><?php echo $sCarrera;?></strong></h5>

				
				
			</div>
		</div>


	</div>

	<div class="container well">
		<div class="row">
		<h4 class="text-center">TU HORARIO EN PERIODO : </h4>
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6 col-md-offset-3 col-lg-offset-3" >
				
				<div>

				</div>
			</div>
		</div>
	</div>

	<div class="container well">
		<div class="row">
		<h4 class="text-center">TUS CALIFICACIONES EN PERIODO : </h4>
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6 col-md-offset-3 col-lg-offset-3" >
				
				<div>

				</div>
			</div>
		</div>
	</div>
		
</body>
</html>